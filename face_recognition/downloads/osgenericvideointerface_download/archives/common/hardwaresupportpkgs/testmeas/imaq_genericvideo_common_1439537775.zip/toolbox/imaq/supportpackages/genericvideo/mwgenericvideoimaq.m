function mwgenericvideoimaq
%MWGENERICVIDEOIMAQ Stub placeholder for finding adaptor location.

% Copyright 2014 The MathWorks, Inc.